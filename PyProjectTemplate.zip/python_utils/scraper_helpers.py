from urllib.parse import urljoin

def find_links_by_keywords(soup, keywords, full_url):
    matches = []
    for link in soup.find_all("a"):
        text = link.get_text(strip=True)
        href = link.get("href")
        if not text or not href:
            continue
        if any(k.lower() in text.lower() for k in keywords):
            full_link = urljoin(full_url, href)
            matches.append((text, full_link))
    return matches
