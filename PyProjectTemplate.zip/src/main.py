import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), "..", "python_utils"))

from scraper_helpers import find_links_by_keywords
from file_helpers import ensure_dir

print("🔥 PyProjectTemplate is running!")
